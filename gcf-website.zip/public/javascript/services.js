
$(document).ready(function() {
    $("body").removeClass("fade-out");
});